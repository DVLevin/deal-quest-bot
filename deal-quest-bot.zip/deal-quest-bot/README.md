# 🎮 Deal Quest Bot

**GetDeal.ai Sales Training & Support Platform**

A Telegram bot that helps GetDeal.ai's partnership team:
- Get real-time **closing strategies** for prospects
- Practice sales scenarios with **AI scoring**
- Learn the playbook through **interactive training**

---

## 🚀 Quick Start

### 1. Clone and Install

```bash
cd deal-quest-bot
python -m venv venv
source venv/bin/activate  # or `venv\Scripts\activate` on Windows
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your values:
# - TELEGRAM_BOT_TOKEN (from @BotFather)
# - ENCRYPTION_KEY (generate with the command in .env.example)
```

### 3. Add Company Knowledge

Replace the placeholder in `data/company_knowledge.md` with actual GetDeal.ai company information.

### 4. Run Locally

```bash
python -m bot.main
```

### 5. Deploy to Railway

```bash
railway login
railway init
railway up
```

---

## 📱 Bot Commands

| Command | Description |
|---------|-------------|
| `/start` | Set up your account and API keys |
| `/support` | Get closing strategy for a real prospect |
| `/learn` | Structured training tracks |
| `/train` | Random scenario practice |
| `/stats` | View your progress and XP |
| `/settings` | Change LLM provider or model |

---

## 🏗️ Architecture

```
User (Telegram)
    │
    ▼
Deal Quest Bot
    │
    ├── Strategist Agent (/support)
    │   └── Analyzes prospects, generates strategy + drafts
    │
    ├── Trainer Agent (/learn, /train)
    │   └── Presents scenarios, scores responses
    │
    └── Memory Agent (background)
        └── Updates user memory, manages casebook
    │
    ▼
LLM Router (Claude or OpenRouter)
```

---

## 📁 Project Structure

```
deal-quest-bot/
├── docs/               # Documentation for Claude Code
├── data/               # Knowledge base files
│   ├── playbook.md     # Sales playbook
│   ├── company_knowledge.md  # Company info
│   ├── scenarios.json  # Training scenarios
│   └── user_memory/    # Per-user memory files
├── prompts/            # Agent system prompts
├── bot/                # Application code
│   ├── handlers/       # Telegram command handlers
│   ├── agents/         # Multi-agent system
│   ├── services/       # Business logic
│   └── storage/        # Data persistence
├── .env.example
├── requirements.txt
└── railway.toml
```

---

## 🔑 LLM Provider Options

### OpenRouter (Recommended for cost)

Free models available:
- `qwen/qwen3-coder` — Good general purpose
- `deepseek/deepseek-r1` — Strong reasoning
- `google/gemini-flash` — Fast responses

### Claude API (Best quality)

- `claude-sonnet-4-20250514` — Excellent for role-play and analysis

Users configure their own API keys during `/start` onboarding.

---

## 📊 Features

### Support Mode (`/support`)

Paste prospect context → Get full closing strategy:
- Deep prospect analysis
- Multi-step closing strategy
- Engagement tactics (LinkedIn likes/comments)
- Draft response using playbook language

### Learning Mode (`/learn`)

Structured curriculum:
- Track 1: Foundations (4 levels)
- Lesson → Scenario → Score → Feedback
- Progress tracked with XP

### Training Mode (`/train`)

Case interview-style practice:
- Random scenarios from pool of 20+
- **Never repeats** until all exhausted
- Specific scoring with playbook comparison

### Memory System

- Per-user memory files (YAML)
- Tracks strengths, weaknesses, patterns
- Casebook stores reusable responses
- Reduces LLM costs by ~90% for similar queries

---

## 🛠️ Development

### For Claude Code

Read these files first:
1. `docs/README.md` — Build instructions
2. `docs/ARCHITECTURE.md` — System design
3. `docs/TASK_BRIEF.md` — Feature specs

### Research Before Coding

Always web search for current patterns:
- aiogram 3.x (changed significantly from v2)
- OpenRouter API
- Railway deployment

---

## 📄 License

Internal tool for GetDeal.ai

---

*Built with Claude Code | January 2026*
