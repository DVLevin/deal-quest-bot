# GetDeal.ai Company Knowledge Base

> **⚠️ PLACEHOLDER - Replace with actual company knowledge**
> 
> Run the research request in your GetDeal.ai Claude project to generate this content.

---

## Company Identity

**Company Name:** GetDeal.ai

**One-liner:** [To be filled]

**Founded:** [Date, Location]

**Stage:** [Funding stage]

**Mission:** [Mission statement]

---

## Founding Team

### [Founder 1 Name] — [Title]

- **Background:** [Previous roles]
- **Expertise:** [What they bring]
- **Why GetDeal:** [Personal motivation]

### [Founder 2 Name] — [Title]

- **Background:** [Previous roles]
- **Expertise:** [What they bring]
- **Why GetDeal:** [Personal motivation]

---

## Product & Platform

### What It Is

[Description of the platform]

### Key Features

- Feature 1: [Description]
- Feature 2: [Description]
- Feature 3: [Description]

### AI Capabilities

[What AI specifically does in the platform]

---

## Market Positioning

### Target Sellers

[Specific criteria]

### Target Buyers

[Specific criteria]

### Competitors & Differentiation

| Competitor | How We're Different |
|------------|-------------------|
| Traditional Bankers | [Difference] |
| Other Platforms | [Difference] |

### Unique Value Props

1. [Value prop 1]
2. [Value prop 2]
3. [Value prop 3]

---

## Proof Points

### Traction Metrics

- [Metric 1]: [Value]
- [Metric 2]: [Value]

### Case Studies

[Success stories, if available]

### Social Proof

[Notable customers, press mentions]

---

## Objection Handling (Company-Specific)

### Seller Objections

**"Why not a traditional banker?"**
> [Response]

**"What about confidentiality?"**
> [Response]

### Buyer Objections

**"We have our own deal sourcing"**
> [Response]

**"Why pay for access?"**
> [Response]

---

## Brand Voice

### Tone

[How GetDeal.ai should sound]

### Words to USE

- [Word/phrase 1]
- [Word/phrase 2]

### Words to AVOID

- [Word/phrase 1]
- [Word/phrase 2]

### Elevator Pitches

**30-second version:**
> [Pitch]

**2-minute version:**
> [Pitch]

---

*Replace this placeholder with actual content from company research*
